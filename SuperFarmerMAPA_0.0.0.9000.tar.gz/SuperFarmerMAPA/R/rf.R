#' Random Forest Model
#' 
#' @docType data
#' @name rf
NULL