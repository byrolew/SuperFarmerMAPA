#' Random Forest Model
#' 
#' @docType data
#' @name rfAga
NULL