#' Random Forest Model
#'
#' @docType data
#' @name forest
NULL
