#' Macierz wymiany na większe zwierzę
#'
#' @docType data
#' @name to_big_animal
NULL
