#' Macierz wymiany na mniejsze zwierzęta
#'
#' @docType data
#' @name to_small_animals
NULL
